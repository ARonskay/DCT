import cv2
import numpy as np
import time


def get_dct_matrix(size):
    ''' zwraca macierz size x size (transformacji) DCT '''
    dmat = np.zeros((size, size), dtype=np.float64)
    for u in range(size):
        c_u = np.sqrt(1. / size) if u == 0 else np.sqrt(2. / size)
        for v in range(size):
            dmat[u, v] = c_u * np.cos((2 * v + 1) * u * np.pi / (2 * size))
    return dmat


def get_dct_matrix_irr(ysize, xsize):
    ''' liczy macierz DCT dla CAŁEGO obrazu '''
    pass
    '''
    dmat = np.zeros((size, size), dtype=np.float64)
    for u in range(size):
        c_u = np.sqrt(1. / size) if u == 0 else np.sqrt(2. / size)
        for v in range(size):
            dmat[u, v] = c_u * np.cos((2 * v + 1) * u * np.pi / (2 * size))
            
    return dmat
    '''


# oblicza dct
def dct(img_bl, dctmat):
    return dctmat @ img_bl @ dctmat.transpose()


# oblicza idct
def idct(coeffs_bl, dctmat):
    return (dctmat.transpose() @ coeffs_bl @ dctmat).round().clip(0, 255)


def dct_image(image, blsize, dctmat=None):
    if dctmat is None:
        dctmat = get_dct_matrix(blsize)
    num_bl_x = image.shape[1] // blsize
    num_bl_y = image.shape[0] // blsize
    dct_coeffs = np.zeros_like(image, dtype=np.float64)
    for blx in range(num_bl_x):
        for bly in range(num_bl_y):
            img_bl = image[bly * blsize:(bly + 1) * blsize, blx * blsize:(blx + 1) * blsize]
            # dct_coeffs[bly*blsize:(bly+1)*blsize, blx*blsize:(blx+1)*blsize] = dctmat @ img_bl @ dctmat.transpose()
            dct_coeffs[bly * blsize:(bly + 1) * blsize, blx * blsize:(blx + 1) * blsize] = dct(img_bl, dctmat)
    return dct_coeffs


def idct_image(coeffs, blsize, dctmat=None):
    if dctmat is None:
        dctmat = get_dct_matrix(blsize)
    num_bl_x = coeffs.shape[1] // blsize
    num_bl_y = coeffs.shape[0] // blsize
    img_rec = np.zeros_like(coeffs, dtype=np.uint8)
    for blx in range(num_bl_x):
        for bly in range(num_bl_y):
            coeffs_bl = coeffs[bly * blsize:(bly + 1) * blsize, blx * blsize:(blx + 1) * blsize]
            # img_rec[bly*blsize:(bly+1)*blsize, blx*blsize:(blx+1)*blsize] = \
            #     (dctmat.transpose() @ coeffs_bl @ dctmat).round()
            img_rec[bly * blsize:(bly + 1) * blsize, blx * blsize:(blx + 1) * blsize] = idct(coeffs_bl, dctmat)
    return img_rec


def select_q_matrix(q_matrix):
    q10 = np.array([[80, 60, 50, 80, 120, 200, 255, 255],
                    [55, 60, 70, 95, 130, 255, 255, 255],
                    [70, 65, 80, 120, 200, 255, 255, 255],
                    [70, 85, 110, 145, 255, 255, 255, 255],
                    [90, 110, 185, 255, 255, 255, 255, 255],
                    [120, 175, 255, 255, 255, 255, 255, 255],
                    [245, 255, 255, 255, 255, 255, 255, 255],
                    [255, 255, 255, 255, 255, 255, 255, 255]])

    q50 = np.array([[16, 11, 10, 16, 24, 40, 51, 61],
                    [12, 12, 14, 19, 26, 58, 60, 55],
                    [14, 13, 16, 24, 40, 57, 69, 56],
                    [14, 17, 22, 29, 51, 87, 80, 62],
                    [18, 22, 37, 56, 68, 109, 103, 77],
                    [24, 35, 55, 64, 81, 104, 113, 92],
                    [49, 64, 78, 87, 103, 121, 120, 101],
                    [72, 92, 95, 98, 112, 100, 130, 99]])

    q90 = np.array([[3, 2, 2, 3, 5, 8, 10, 12],
                    [2, 2, 3, 4, 5, 12, 12, 11],
                    [3, 3, 3, 5, 8, 11, 14, 11],
                    [3, 3, 4, 6, 10, 17, 16, 12],
                    [4, 4, 7, 11, 14, 22, 21, 15],
                    [5, 7, 11, 13, 16, 12, 23, 18],
                    [10, 13, 16, 17, 21, 24, 24, 21],
                    [14, 18, 19, 20, 22, 20, 20, 20]])

    # macierz sandboxowa do modyfikacji
    qXX = np.array([[0, 1, 1, 1, 5, 8, 10, 12],
                    [2, 2, 3, 4, 5, 12, 12, 11],
                    [3, 3, 3, 5, 8, 11, 14, 11],
                    [3, 3, 4, 6, 10, 17, 16, 12],
                    [4, 4, 7, 11, 14, 22, 21, 15],
                    [5, 7, 11, 13, 16, 12, 23, 18],
                    [10, 13, 16, 17, 21, 24, 24, 21],
                    [14, 18, 19, 20, 22, 20, 20, 20]])

    if q_matrix == "q10":
        return q10
    elif q_matrix == "q50":
        return q50
    elif q_matrix == "q90":
        return q90
    elif q_matrix == "qXX":
        return qXX
    else:
        return np.ones((8, 8))  # zwraca obraz oryginalny


def choose_coeffs_magn(coeffs, cnt):
    """ Wybiera z danego bloku okresloną liczbę współczynników o największej amplitudzie. """
    abs_coeffs = np.abs(coeffs)  # obliczenie amplitudy (zwracana jest kopia tablicy)
    new_coeffs = np.zeros_like(coeffs)  # utworzenie tablicy wyjściowej - poczatkowo same zera
    for _ in range(cnt):
        # argmax zwraca liczbe, odpowiadajaca pozycji w tablicy flatten
        # unravel_index zwraca tuple ze wspolrzednymi w odniesieniu do tablicy 2d: 'abs_coeffs'
        mat_idx = np.unravel_index(np.argmax(abs_coeffs), abs_coeffs.shape)  # znalezienie indeksu majwiększej wartości
        new_coeffs[mat_idx] = coeffs[mat_idx]  # zapisanie współczynnika w tablicy wyjściowej
        abs_coeffs[mat_idx] = 0  # wyzerowanie w tablicy wejściowej - żeby można było znaleźć kolejny max
    return new_coeffs


def apply_chosen_coeffs_magn(big_matrix, bl_size, cnt):
    """ funkcja wybiera CNT wspolczynnikow z kazdego bloku w calej BIG_MATRIX """
    """ big_matrix to macierz o wymiarach obrazu ze wspolczynnikami """

    num_bl_x = big_matrix.shape[1] // bl_size
    num_bl_y = big_matrix.shape[0] // bl_size
    mtx_res = np.zeros_like(big_matrix)
    # TODO ustalic typ mtx_res

    for blx in range(num_bl_x):
        for bly in range(num_bl_y):
            coeffs_bl = big_matrix[bly * bl_size:(bly + 1) * bl_size, blx * bl_size:(blx + 1) * bl_size]
            chosen_coeffs_bl = choose_coeffs_magn(coeffs_bl, cnt)
            mtx_res[bly*bl_size:(bly+1)*bl_size, blx*bl_size:(blx+1)*bl_size] = chosen_coeffs_bl

    return mtx_res


# TODO funckja wybiera iles najwiekszych wspolczynnikow z CALEJ macierzy
#  ( dla metody blokowej dziala? czy tylko dla DCT dla calego obrazu?)


def modify_quant_matrix(quality,coordinates, step):
    pass
    """ funkcja, która przyjmuje macierz "jedynkowa" 8x8 i modyfikuje dany jej element z KROKIEM """
    # czyli np dla [0,0] pierwszy rząd wyglada tak:   8 1 1 1 1 1 1 1
    # lub                                           50 1 1 1 1 1 1 1
    # lub                                           170 1 1 1 1 1 1 1
    # return new_quant_mtx


def quant_operation(small_block, q_matrix, kind):
    """ Funckja pomocnicza do wyboru rodzaju kwantyzacji;  "d" divide, "m" multipy """

    if kind == "d":
        quant_matrix = small_block / q_matrix
    else:
        quant_matrix = small_block * q_matrix
    return quant_matrix


def quant_once(big_matrix, x_blocks, y_blocks, q_matrix, kind):
    """ Jeden proces kwantyzacji """

    quant_matrix = np.zeros_like(big_matrix)
    block_size = len(q_matrix)

    for blx in range(x_blocks):
        for bly in range(y_blocks):
            block = big_matrix[bly * block_size: (bly + 1) * block_size, blx * block_size: (blx + 1) * block_size]
            quant_matrix[bly * block_size: (bly + 1) * block_size, blx * block_size: (blx + 1) * block_size] = \
                np.round_(quant_operation(block, q_matrix, kind))
    return quant_matrix


def quantize_full(dct_coeffs_matrix, quality):  # quality -> podaje sie:  "qXX"
    """ Najwazniejsza funkcja kwantyzujaca, przeprowadza rowniez proces dekwantyzacji """
    q_matrix = select_q_matrix(quality)
    no_x_blocks = dct_coeffs_matrix.shape[1] // len(q_matrix)  # q_matrix jest 8x8 wiec 8
    no_y_blocks = dct_coeffs_matrix.shape[0] // len(q_matrix)
    # block_size wybierany na podstawie macierzy jakości QUALITY

    after_quant_matrix = np.zeros_like(dct_coeffs_matrix, dtype=np.int16)  # dtype=np.float64 dtype=np.uint8
    # TODO ustalic typ after_quant_matrix

    quant_temp = quant_once(dct_coeffs_matrix, no_x_blocks, no_y_blocks, q_matrix, "d")
    after_quant_matrix = quant_once(quant_temp, no_x_blocks, no_y_blocks, q_matrix, "m")
    # print(f"\n\n\n\n##########\n {type(after_quant_matrix[0,0])}\n\n\n\n")
    return after_quant_matrix


# def quantize2(dct_coeffs_matrix, quality):  # quality -> podaje sie:  "qXX"
#     q_matrix = select_q_matrix(quality)
#     num_bl_x = dct_coeffs_matrix.shape[1] // len(q_matrix)  # q_matrix jest 8x8 wiec 8
#     num_bl_y = dct_coeffs_matrix.shape[0] // len(q_matrix)
#     block_size = len(q_matrix)  # block_size wybierany na podstawie macierzy jakości QUALITY
#
#     after_quant_matrix1 = np.zeros_like(dct_coeffs_matrix)  # dtype=np.float64 dtype=np.uint8
#     after_quant_matrix2 = np.zeros_like(dct_coeffs_matrix)
#
#     for blx in range(num_bl_x):
#         for bly in range(num_bl_y):
#             block_dct_coeffs = dct_coeffs_matrix[bly * block_size: (bly + 1) * block_size,
#                                blx * block_size: (blx + 1) * block_size]
#             after_quant_matrix1[bly * block_size: (bly + 1) * block_size, blx * block_size: (blx + 1) * block_size] = \
#                 np.round_(quant_operation(block_dct_coeffs, q_matrix, "d"))
#
#             block_idct_coeffs = after_quant_matrix1[bly * block_size: (bly + 1) * block_size,
#                                 blx * block_size: (blx + 1) * block_size]
#             after_quant_matrix2[bly * block_size: (bly + 1) * block_size, blx * block_size: (blx + 1) * block_size] = \
#                 quant_operation(block_idct_coeffs, q_matrix, "m")
#
#     return after_quant_matrix2

def test_dct_calc():
    """ Sprawdzenie poprawności obliczania DCT/IDCT. """
    img = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)

    dct_coeffs = dct_image(img, 8)
    # print(f"BBB: {dct_coeffs.shape}")
    # print(dct_coeffs)
    img_rec = idct_image(dct_coeffs, 8)
    print(img_rec)
    cv2.imshow("Oryginalny", img)
    cv2.imshow("DCT", dct_coeffs)
    cv2.imshow("Wynikowy", img_rec)
    cv2.imwrite("test.png", img_rec)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    print(f"{(img == img_rec).all()}")


def test_dct_quantize():
    """ Sprawdzenie poprawności obliczania DCT/IDCT. """
    img = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)
    #img = cv2.imread("lena_grey_scaled.png", cv2.IMREAD_UNCHANGED)
    # img = cv2.imread("lena_grey_scaled.png", cv2.IMREAD_UNCHANGED) # 275,323,3
    # print(f"\n##### {img.shape}\n")
    # dct_coeffs = dct_image(img[:, :, 0], 8)
    dct_coeffs = dct_image(img, 8)
    result_of_quant = quantize_full(dct_coeffs, "q90")
    # print(f"\n\n   {result_of_quant.shape} {result_of_quant[511,511]} \n\n")
    img_rec = idct_image(result_of_quant, 8)

    cv2.imshow("Poczatkowy", img)
    cv2.imshow("Po DCT", dct_coeffs)
    cv2.imshow("Po kwantyzacji", result_of_quant)
    cv2.imshow("Wynikowy", img_rec)
    # cv2.imwrite("Irregular2.jpg", img_rec)
    # cv2.imwrite("QualityPNG90.png", img_rec)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


# TODO test dzialnia DCT dla calego obrazu
def test_dct_full_image():

    img = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)
    x_size = img.shape[1]

    dct_coeffs = dct_image(img, 8)
    img_rec = idct_image(dct_coeffs, 8)

    return img_rec


def test_magnitude_choiceAFTEREQ():
    # img = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)
    img = cv2.imread("lena_grey_scaled.png", cv2.IMREAD_GRAYSCALE)
    dct_coeffs = dct_image(img, 8)
    result_of_quant = quantize_full(dct_coeffs, "q10")
    # TODO kiedy dac apply_magnitude przed czy po kwantyzacji
    result_of_choice = apply_chosen_coeffs_magn(result_of_quant, 8, 1)  # JEDEN najwiekszy wspolczynnik
    img_rec = idct_image(result_of_choice, 8)
    cv2.imwrite("AAAAAA.jpg", img_rec)
    cv2.imshow("Poczatkowy", img)
    cv2.imshow("Po DCT", dct_coeffs)
    cv2.imshow("Po wyborze", result_of_choice)
    cv2.imshow("Po kwantyzacji", result_of_quant)
    cv2.imshow("Wynikowy", img_rec)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def test_magnitude_choiceBEFOREQ():
    img = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)
    dct_coeffs = dct_image(img, 8)
    result_of_choice = apply_chosen_coeffs_magn(dct_coeffs, 8, 1)  # JEDEN najwiekszy wspolczynnik
    result_of_quant = quantize_full(result_of_choice, "q10")
    # TODO kiedy dac apply_magnitude przed czy po kwantyzacji
    img_rec = idct_image(result_of_quant, 8)
    # cv2.imwrite("q50_1wspl_WYBORprzedKWANT.jpg", img_rec)
    cv2.imshow("Poczatkowy", img)
    cv2.imshow("Po DCT", dct_coeffs)
    cv2.imshow("Po wyborze", result_of_choice)
    cv2.imshow("Po kwantyzacji", result_of_quant)
    cv2.imshow("Wynikowy_1wspol", img_rec)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

''' po porownaniu obrazkow oraz ich macierzy 20x14 nie widac roznicy dla wyboru przed lub po kwantyzacji '''


if __name__ == "__main__":
    start_wall_time = time.time()
    start_cpu_time = time.process_time()
    '''
    image = cv2.imread("lena_mono.png", cv2.IMREAD_UNCHANGED)
    # print(image)
    a = get_dct_matrix(8)
    # print(a)
    print("---------------------\nAAAAAAAAAAAAAAAAAAAAA")
    b = dct_image(image, 8)
    print(b)
    # print(len(b))
    print(b.shape)
    print("---------------------\nAAAAAAAAAAAAAAAAAAAAA")
    fragment_dct_image = b[:8, : 8]
    # print(fragment_dct_image)

    quant_mtx = quantize_full(b, "q90")
    print(quant_mtx.shape)
    print(quant_mtx[:8, : 8])
    print(type(quant_mtx))
    # np.savetxt("file2.txt", quant_mtx)

    # Displaying the contents of the text file
    # content = numpy.loadtxt('file2.txt')
    # print("\nContent in file2.txt:\n", content)

    img_rec_a = np.zeros_like(image, dtype=np.uint8)
    print("---------------------\nAAAAAAAAAAAAAAAAAAAAA")
    # test_dct_calc()
    print("---------------------\nAAAAAAAAAAAAAAAAAAAAA")
    #test_dct_calc()
    test_dct_quantize()
    gg = get_dct_matrix(8)
    print("\n\n\n")
    print(gg)
    print("\n\n\n")
    print(len(select_q_matrix("q10")))
    '''
    #test_magnitude_choiceAFTEREQ()
    test_magnitude_choiceBEFOREQ()
    #test_dct_quantize()
    # test_dct_calc()
    end_cpu_time = time.process_time()
    end_wall_time = time.time()

    elapsed_wall_time = end_wall_time - start_wall_time
    elapsed_cpu_time = end_cpu_time - start_cpu_time
    print('Execution Wall time:', elapsed_wall_time, 'seconds')
    print('Execution CPU time:', elapsed_cpu_time, 'seconds')
