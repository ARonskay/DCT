import tkinter
from tkinter import *
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo
from tkinter.filedialog import *
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from PIL import ImageTk,Image
from PyQt5 import QtWidgets, Qt, QtCore
import os
import fileinput
from PIL import Image, ImageTk


root = Tk()
root.minsize(width=1200, height=800)
root.wm_title("Window Title")
root.config(background = "#FFFFFF")

def open_file():
    global content
    global file_path

    filename = askopenfilename()
    infile = open(filename, 'rb')
    content = infile.read()
    file_path = os.path.abspath(filename)
    tekst1.delete(0, END)
    tekst1.insert(0, file_path)
    return content


wartoscb1 = 16
wartoscb2 = 11
wartoscb3 = 10
wartoscb4 = 16
wartoscb5 = 24
wartoscb6 = 40
wartoscb7 = 51
wartoscb8 = 61
wartoscb9 = 12
wartoscb10 = 12
wartoscb11 = 14
wartoscb12 = 19
wartoscb13 = 26
wartoscb14 = 48
wartoscb15 = 60
wartoscb16 = 55
wartoscb17 = 14
wartoscb18 = 13
wartoscb19 = 16
wartoscb20 = 24
wartoscb21 = 40
wartoscb22 = 57
wartoscb23 = 69
wartoscb24 = 56
wartoscb25 = 14
wartoscb26 = 17
wartoscb27 = 22
wartoscb28 = 29
wartoscb29 = 51
wartoscb30 = 87
wartoscb31 = 80
wartoscb32 = 62
wartoscb33 = 18
wartoscb34 = 22
wartoscb35 = 37
wartoscb36 = 56
wartoscb37 = 68
wartoscb38 = 109
wartoscb39 = 103
wartoscb40 = 77
wartoscb41 = 24
wartoscb42 = 35
wartoscb43 = 55
wartoscb44 = 64
wartoscb45 = 81
wartoscb46 = 104
wartoscb47 = 113
wartoscb48 = 92
wartoscb49 = 49
wartoscb50 = 64
wartoscb51 = 78
wartoscb52 = 87
wartoscb53 = 103
wartoscb54 = 121
wartoscb55 = 120
wartoscb56 = 101
wartoscb57 = 72
wartoscb58 = 92
wartoscb59 = 95
wartoscb60 = 98
wartoscb61 = 112
wartoscb62 = 100
wartoscb63 = 103
wartoscb64 = 99


'''
for el in range(1,65):
    wartosc + str(el) = mat[x,y]
'''

def callback(event):
    root.focus_set()
    if B1.bind("<Button-3>", callback):
        global wartoscb1
        wartoscb1 += -1
        B1['text'] = wartoscb1
def callback2(event):
    root.focus_set()
    if B1.bind("<Button-1>", callback2):
        global wartoscb1
        wartoscb1 += 1
        B1['text'] = wartoscb1
def b1():
    B1.bind("<Button-3>", callback)
    B1.bind("<Button-1>", callback2)
def b2():
    global wartoscb2
    wartoscb2 += 1
    B2['text']=wartoscb2
def b3():
    global wartoscb3
    wartoscb3 += 1
    B3['text']=wartoscb3
def b4():
    global wartoscb4
    wartoscb4 += 1
    B4['text']=wartoscb4
def b5():
    global wartoscb5
    wartoscb5 += 1
    B5['text']=wartoscb5
def b6():
    global wartoscb6
    wartoscb6 += 1
    B6['text']=wartoscb6
def b7():
    global wartoscb7
    wartoscb7 += 1
    B7['text']=wartoscb7
def b8():
    global wartoscb8
    wartoscb8 += 1
    B8['text']=wartoscb8
def b9():
    global wartoscb9
    wartoscb9 += 1
    B9['text']=wartoscb9
def b10():
    global wartoscb10
    wartoscb10 += 1
    B10['text']=wartoscb10
def b11():
    global wartoscb11
    wartoscb11 += 1
    B11['text']=wartoscb11
def b12():
    global wartoscb12
    wartoscb12 += 1
    B12['text']=wartoscb12
def b13():
    global wartoscb13
    wartoscb13 += 1
    B13['text']=wartoscb13
def b14():
    global wartoscb14
    wartoscb14 += 1
    B14['text']=wartoscb14
def b15():
    global wartoscb15
    wartoscb15 += 1
    B15['text']=wartoscb15
def b16():
    global wartoscb16
    wartoscb16 += 1
    B16['text']=wartoscb16
def b17():
    global wartoscb17
    wartoscb17 += 1
    B17['text']=wartoscb17
def b18():
    global wartoscb18
    wartoscb18 += 1
    B18['text']=wartoscb18
def b19():
    global wartoscb19
    wartoscb19 += 1
    B19['text']=wartoscb19
def b20():
    global wartoscb20
    wartoscb20 += 1
    B20['text']=wartoscb20
def b21():
    global wartoscb21
    wartoscb21 += 1
    B21['text']=wartoscb21
def b22():
    global wartoscb22
    wartoscb22 += 1
    B22['text']=wartoscb22
def b23():
    global wartoscb23
    wartoscb23 += 1
    B23['text']=wartoscb23
def b24():
    global wartoscb24
    wartoscb24 += 1
    B24['text']=wartoscb24
def b25():
    global wartoscb25
    wartoscb25 += 1
    B25['text']=wartoscb25
def b26():
    global wartoscb26
    wartoscb26 += 1
    B26['text']=wartoscb26
def b27():
    global wartoscb27
    wartoscb27 += 1
    B27['text']=wartoscb27
def b28():
    global wartoscb28
    wartoscb28 += 1
    B28['text']=wartoscb28
def b29():
    global wartoscb29
    wartoscb29 += 1
    B29['text']=wartoscb29
def b30():
    global wartoscb30
    wartoscb30 += 1
    B30['text']=wartoscb30
def b31():
    global wartoscb31
    wartoscb31 += 1
    B31['text']=wartoscb31
def b32():
    global wartoscb32
    wartoscb32 += 1
    B32['text']=wartoscb32
def b33():
    global wartoscb33
    wartoscb33 += 1
    B33['text']=wartoscb33
def b34():
    global wartoscb34
    wartoscb34 += 1
    B34['text']=wartoscb34
def b35():
    global wartoscb35
    wartoscb35 += 1
    B35['text']=wartoscb35
def b36():
    global wartoscb36
    wartoscb36 += 1
    B36['text']=wartoscb36
def b37():
    global wartoscb37
    wartoscb37 += 1
    B37['text']=wartoscb37
def b38():
    global wartoscb38
    wartoscb38 += 1
    B38['text']=wartoscb38
def b39():
    global wartoscb39
    wartoscb39 += 1
    B39['text']=wartoscb39
def b40():
    global wartoscb40
    wartoscb40 += 1
    B40['text']=wartoscb40
def b41():
    global wartoscb41
    wartoscb41 += 1
    B41['text']=wartoscb41
def b42():
    global wartoscb42
    wartoscb42 += 1
    B42['text']=wartoscb42
def b43():
    global wartoscb43
    wartoscb43 += 1
    B43['text']=wartoscb43
def b44():
    global wartoscb44
    wartoscb44 += 1
    B44['text']=wartoscb44
def b45():
    global wartoscb45
    wartoscb45 += 1
    B45['text']=wartoscb45
def b46():
    global wartoscb46
    wartoscb46 += 1
    B46['text']=wartoscb46
def b47():
    global wartoscb47
    wartoscb47 += 1
    B47['text']=wartoscb47
def b48():
    global wartoscb48
    wartoscb48 += 1
    B48['text']=wartoscb48
def b49():
    global wartoscb49
    wartoscb49 += 1
    B49['text']=wartoscb49
def b50():
    global wartoscb50
    wartoscb50 += 1
    B50['text']=wartoscb50
def b51():
    global wartoscb51
    wartoscb51 += 1
    B51['text']=wartoscb51
def b52():
    global wartoscb52
    wartoscb52 += 1
    B52['text']=wartoscb52
def b53():
    global wartoscb53
    wartoscb53 += 1
    B53['text']=wartoscb53
def b54():
    global wartoscb54
    wartoscb54 += 1
    B54['text']=wartoscb54
def b55():
    global wartoscb55
    wartoscb55 += 1
    B55['text']=wartoscb55
def b56():
    global wartoscb56
    wartoscb56 += 1
    B56['text']=wartoscb56
def b57():
    global wartoscb57
    wartoscb57 += 1
    B57['text']=wartoscb57
def b58():
    global wartoscb58
    wartoscb58 += 1
    B58['text']=wartoscb58
def b59():
    global wartoscb59
    wartoscb59 += 1
    B59['text']=wartoscb59
def b60():
    global wartoscb60
    wartoscb60 += 1
    B60['text']=wartoscb60
def b61():
    global wartoscb61
    wartoscb61 += 1
    B61['text']=wartoscb61
def b62():
    global wartoscb62
    wartoscb62 += 1
    B62['text']=wartoscb62
def b63():
    global wartoscb63
    wartoscb63 += 1
    B63['text']=wartoscb63
def b64():
    global wartoscb64
    wartoscb64 += 1
    B64['text']=wartoscb64



upframe = Frame(root,width=1190, height = 100, bg='white',highlightbackground="gray", highlightthickness=1)
#upframe.pack(side = LEFT)
upframe.place(x=5, y=5)


photoframe = Frame(root, width=700, height=600, bg = 'pink',highlightbackground="gray", highlightthickness=12)
photoframe.place(x=20, y=120)

infoframe = Frame(root, width=390, height=650, bg = 'grey')
infoframe.place(x=780, y=120)

matrixframe = Frame(infoframe, width=352, height=352, bg = 'blue')
matrixframe.place(x=20, y=20)



file_path = StringVar()
Btnfile = Button(upframe, width=20, height=20, text="Browse",highlightbackground="gray", highlightthickness=2,command=open_file)
Btnfile.place(width=100,height=30,x=500,y=15)
Btnfile.place(x=540,y=15)

input_text = StringVar()
tekst1 = tkinter.Entry(upframe, width=80,  textvariable=file_path, bg='white',highlightbackground="gray", highlightthickness=2)
tekst1.place(width=510,height=30,x=10,y=15)
tekst1.place(x=10,y=15)

Btnstart = Button(upframe, width=300, height=20, text="Start",bg="#ADFF2F", font='Times 15')
Btnstart.place(width=340,height=30,x=750,y=55)
Btnstart.place(x=750,y=55)

labelPSNR = Label(infoframe, text='PSNR:',bg="gray",font='Times 20', fg='#000000')
labelPSNR.place(width=100,height=40,x=40,y=390)

labelPSNRdata = Label(infoframe, text='?',bg="gray",font='Times 20', fg='#000000')
labelPSNRdata.place(width=100,height=40,x=160,y=390)

labelSSIM = Label(infoframe, text='SSIM:',bg="gray",font='Times 20', fg='#000000')
labelSSIM.place(width=100,height=40,x=40,y=450)

labelSSIMdata = Label(infoframe, text='?',bg="gray",font='Times 20', fg='#000000')
labelSSIMdata.place(width=100,height=40,x=160,y=450)

Btn1 = Button(root, text="Przycisk1")
Btn1.place(x=130,y=740)

Btn2 = Button(root, text="Przycisk2")
Btn2.place(x=330,y=740)

Btn3 = Button(root, text="Przycisk3")
Btn3.place(x=530,y=740)

var = IntVar()
R1 = Radiobutton(upframe, text="8x8", variable=var, value=1)
R1.place(width=100,height=30,x=750,y=15)
#R1.pack( anchor = W )



R3 = Radiobutton(upframe, text="cały", variable=var, value=3)
R3.place(width=100,height=30,x=990,y=15)
#R3.pack( anchor = W)

##############################################  WSPOLCZYNNIKI #################################################################################################
B1 = Button(matrixframe, text="16",command=b1)
B1.place(width=43.75,height=43.75,x=0,y=0)

B2 = Button(matrixframe, text="11",command=b2)
B2.place(width=43.75,height=43.75,x=43.75,y=0)

B3 = Button(matrixframe, text="10",command=b3)
B3.place(width=43.75,height=43.75,x=87.5,y=0)

B4 = Button(matrixframe, text="16",command=b4)
B4.place(width=43.75,height=43.75,x=132,y=0)

B5 = Button(matrixframe, text="24",command=b5)
B5.place(width=43.75,height=43.75,x=176,y=0)

B6 = Button(matrixframe, text="40",command=b6)
B6.place(width=43.75,height=43.75,x=219.75,y=0)

B7 = Button(matrixframe, text="51",command=b7)
B7.place(width=43.75,height=43.75,x=263.75,y=0)

B8 = Button(matrixframe, text="61",command=b8)
B8.place(width=43.75,height=43.75,x=307.75,y=0)

B9 = Button(matrixframe, text="12",command=b9)
B9.place(width=43.75,height=43.75,x=0,y=43.75)

B10= Button(matrixframe, text="12",command=b10)
B10.place(width=43.75,height=43.75,x=43.75,y=43.75)

B11 = Button(matrixframe, text="14",command=b11)
B11.place(width=43.75,height=43.75,x=87.5,y=43.75)

B12 = Button(matrixframe, text="19",command=b12)
B12.place(width=43.75,height=43.75,x=132,y=43.75)

B13 = Button(matrixframe, text="26",command=b13)
B13.place(width=43.75,height=43.75,x=176,y=43.75)

B14 = Button(matrixframe, text="48",command=b14)
B14.place(width=43.75,height=43.75,x=219.75,y=43.75)

B15 = Button(matrixframe, text="60",command=b15)
B15.place(width=43.75,height=43.75,x=263.75,y=43.75)

B16 = Button(matrixframe, text="55",command=b16)
B16.place(width=43.75,height=43.75,x=307.75,y=43.75)

B17 = Button(matrixframe, text="14",command=b17)
B17.place(width=43.75,height=43.75,x=0,y=87.5)

B18= Button(matrixframe, text="13",command=b18)
B18.place(width=43.75,height=43.75,x=43.75,y=87.5)

B19 = Button(matrixframe, text="16",command=b19)
B19.place(width=43.75,height=43.75,x=87.5,y=87.5)

B20 = Button(matrixframe, text="24",command=b20)
B20.place(width=43.75,height=43.75,x=132,y=87.5)

B21 = Button(matrixframe, text="40",command=b21)
B21.place(width=43.75,height=43.75,x=176,y=87.5)

B22 = Button(matrixframe, text="57",command=b22)
B22.place(width=43.75,height=43.75,x=219.75,y=87.5)

B23 = Button(matrixframe, text="69",command=b23)
B23.place(width=43.75,height=43.75,x=263.75,y=87.5)

B24 = Button(matrixframe, text="56",command=b24)
B24.place(width=43.75,height=43.75,x=307.75,y=87.5)

B25 = Button(matrixframe, text="14",command=b25)
B25.place(width=43.75,height=43.75,x=0,y=132)

B26= Button(matrixframe, text="17",command=b26)
B26.place(width=43.75,height=43.75,x=43.75,y=132)

B27 = Button(matrixframe, text="22",command=b27)
B27.place(width=43.75,height=43.75,x=87.5,y=132)

B28 = Button(matrixframe, text="29",command=b28)
B28.place(width=43.75,height=43.75,x=132,y=132)

B29 = Button(matrixframe, text="51",command=b29)
B29.place(width=43.75,height=43.75,x=176,y=132)

B30 = Button(matrixframe, text="87",command=b30)
B30.place(width=43.75,height=43.75,x=219.75,y=132)

B31 = Button(matrixframe, text="80",command=b31)
B31.place(width=43.75,height=43.75,x=263.75,y=132)

B32 = Button(matrixframe, text="62",command=b32)
B32.place(width=43.75,height=43.75,x=307.75,y=132)

B33 = Button(matrixframe, text="18",command=b33)
B33.place(width=43.75,height=43.75,x=0,y=176)

B34= Button(matrixframe, text="22",command=b34)
B34.place(width=43.75,height=43.75,x=43.75,y=176)

B35 = Button(matrixframe, text="37",command=b35)
B35.place(width=43.75,height=43.75,x=87.5,y=176)

B36 = Button(matrixframe, text="56",command=b36)
B36.place(width=43.75,height=43.75,x=132,y=176)

B37 = Button(matrixframe, text="68",command=b37)
B37.place(width=43.75,height=43.75,x=176,y=176)

B38 = Button(matrixframe, text="109",command=b38)
B38.place(width=43.75,height=43.75,x=219.75,y=176)

B39 = Button(matrixframe, text="103",command=b39)
B39.place(width=43.75,height=43.75,x=263.75,y=176)

B40 = Button(matrixframe, text="77",command=b40)
B40.place(width=43.75,height=43.75,x=307.75,y=176)

B41 = Button(matrixframe, text="24",command=b41)
B41.place(width=43.75,height=43.75,x=0,y=219.75)

B42= Button(matrixframe, text="35",command=b42)
B42.place(width=43.75,height=43.75,x=43.75,y=219.75)

B43 = Button(matrixframe, text="55",command=b43)
B43.place(width=43.75,height=43.75,x=87.5,y=219.75)

B44 = Button(matrixframe, text="64",command=b44)
B44.place(width=43.75,height=43.75,x=132,y=219.75)

B45 = Button(matrixframe, text="81",command=b45)
B45.place(width=43.75,height=43.75,x=176,y=219.75)

B46 = Button(matrixframe, text="104",command=b46)
B46.place(width=43.75,height=43.75,x=219.75,y=219.75)

B47 = Button(matrixframe, text="113",command=b47)
B47.place(width=43.75,height=43.75,x=263.75,y=219.75)

B48 = Button(matrixframe, text="92",command=b48)
B48.place(width=43.75,height=43.75,x=307.75,y=219.75)

B49 = Button(matrixframe, text="49",command=b49)
B49.place(width=43.75,height=43.75,x=0,y=263.75)

B50= Button(matrixframe, text="64",command=b50)
B50.place(width=43.75,height=43.75,x=43.75,y=263.75)

B51 = Button(matrixframe, text="78",command=b51)
B51.place(width=43.75,height=43.75,x=87.5,y=263.75)

B52 = Button(matrixframe, text="87",command=b52)
B52.place(width=43.75,height=43.75,x=132,y=263.75)

B53 = Button(matrixframe, text="103",command=b53)
B53.place(width=43.75,height=43.75,x=176,y=263.75)

B54 = Button(matrixframe, text="121",command=b54)
B54.place(width=43.75,height=43.75,x=219.75,y=263.75)

B55 = Button(matrixframe, text="120",command=b55)
B55.place(width=43.75,height=43.75,x=263.75,y=263.75)

B56 = Button(matrixframe, text="101",command=b56)
B56.place(width=43.75,height=43.75,x=307.75,y=263.75)

B57 = Button(matrixframe, text="72",command=b57)
B57.place(width=43.75,height=43.75,x=0,y=307.75)

B58= Button(matrixframe, text="92",command=b58)
B58.place(width=43.75,height=43.75,x=43.75,y=307.75)

B59 = Button(matrixframe, text="95",command=b59)
B59.place(width=43.75,height=43.75,x=87.5,y=307.75)

B60 = Button(matrixframe, text="98",command=b60)
B60.place(width=43.75,height=43.75,x=132,y=307.75)

B61 = Button(matrixframe, text="112",command=b61)
B61.place(width=43.75,height=43.75,x=176,y=307.75)

B62 = Button(matrixframe, text="100",command=b62)
B62.place(width=43.75,height=43.75,x=219.75,y=307.75)

B63 = Button(matrixframe, text="103",command=b63)
B63.place(width=43.75,height=43.75,x=263.75,y=307.75)

B64 = Button(matrixframe, text="99",command=b64)
B64.place(width=43.75,height=43.75,x=307.75,y=307.75)


"""
openfileBtn = Button(upframe, text="Open file",command=openfile)
openfileBtn.place(x=120,y=20)
"""



root.mainloop() #start monitoring and updating the GUI

